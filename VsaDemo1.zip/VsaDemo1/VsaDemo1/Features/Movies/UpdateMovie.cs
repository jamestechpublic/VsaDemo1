using MediatR;
using VsaDemo1.Api.Repositories;
using VsaDemo1.Shared;
using VsaDemo1.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace VsaDemo1.Api.Features.Movies
{
    public static class UpdateMovie
    {
        // Command
        public sealed record UpdateMovieCommand(MovieDto Movie) : IRequest<MovieDto?>;

        // Handler
        public sealed class UpdateMovieHandler(MoviesDbContext _context) : IRequestHandler<UpdateMovieCommand, MovieDto?>
        {
            public async Task<MovieDto?> Handle(UpdateMovieCommand request, CancellationToken cancellationToken)
            {
                var entity = await _context.Movies.FindAsync(new object[] { request.Movie.Id }, cancellationToken);
                if (entity is null) return null;

                entity.Title = request.Movie.Title;
                entity.Genre = request.Movie.Genre;
                entity.ReleaseYear = request.Movie.ReleaseYear;

                await _context.SaveChangesAsync(cancellationToken);

                return new MovieDto
                {
                    Id = entity.Id,
                    Title = entity.Title,
                    Genre = entity.Genre,
                    ReleaseYear = entity.ReleaseYear
                };
            }
        }

        // Endpoint mapping
        public static IEndpointRouteBuilder MapUpdateMovie(this IEndpointRouteBuilder app)
        {
            app.MapPut("/movies/{id}", async (int id, MovieDto movie, IMediator mediator) =>
            {
                movie.Id = id;
                var result = await mediator.Send(new UpdateMovieCommand(movie));
                if (result is null) return Results.NotFound("Movie not found.");
                return Results.Ok(result);
            })
            .WithName("UpdateMovie")
            .WithTags("Movies");

            return app;
        }
    }
}
