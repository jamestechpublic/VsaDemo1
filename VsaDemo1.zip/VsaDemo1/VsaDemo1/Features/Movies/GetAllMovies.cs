﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using VsaDemo1.Api.Repositories;
using VsaDemo1.Shared;

namespace VsaDemo1.Api.Features.Movies
{
    public static class GetAllMovies
    {
        // Query
        public sealed record GetAllMoviesQuery() : IRequest<List<MovieDto>>;

        // Handler
        public sealed class GetAllMoviesHandler(MoviesDbContext _context) : IRequestHandler<GetAllMoviesQuery, List<MovieDto>>
        {
            public async Task<List<MovieDto>> Handle(GetAllMoviesQuery request, CancellationToken cancellationToken)
            {
                return await _context.Movies
                    .AsNoTracking()
                    .Select(m => new MovieDto
                    {
                        Id = m.Id,
                        Title = m.Title,
                        Genre = m.Genre,
                        ReleaseYear = m.ReleaseYear
                    })
                    .ToListAsync(cancellationToken);
            }
        }

        // Endpoint mapping
        public static IEndpointRouteBuilder MapGetAllMovies(this IEndpointRouteBuilder app)
        {
            app.MapGet("/movies", async (IMediator mediator) =>
            {
                var result = await mediator.Send(new GetAllMoviesQuery());
                return Results.Ok(result);
            })
            .WithName("GetAllMovies")
            .WithTags("Movies");

            return app;
        }
    }
}
