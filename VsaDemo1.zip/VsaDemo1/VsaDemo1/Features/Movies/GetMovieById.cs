﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using VsaDemo1.Api.Repositories;
using VsaDemo1.Shared;

namespace VsaDemo1.Api.Features.Movies
{
    public static class GetMovieById
    {
        // Query
        public sealed record GetMovieByIdQuery(int id) : IRequest<MovieDto?>;

        // Handler
        public sealed class GetMovieByIdHandler(MoviesDbContext _context) : IRequestHandler<GetMovieByIdQuery, MovieDto?>
        {
            public async Task<MovieDto?> Handle(GetMovieByIdQuery request, CancellationToken cancellationToken)
            {
                return await _context.Movies
                    .AsNoTracking()
                    .Where(m => m.Id == request.id)
                    .Select(m => new MovieDto
                    {
                        Id = m.Id,
                        Title = m.Title,
                        Genre = m.Genre,
                        ReleaseYear = m.ReleaseYear
                    })
                    .FirstOrDefaultAsync(cancellationToken);
            }
        }

        // Endpoint mapping
        public static IEndpointRouteBuilder MapGetMovieById(this IEndpointRouteBuilder app)
        {
            app.MapGet("/movies/{id}", async (int id, IMediator mediator) =>
            {
                var result = await mediator.Send(new GetMovieByIdQuery(id));
                if (result is null) return Results.NotFound("Movie not found.");
                return Results.Ok(result);
            })
            .WithName("GetMovieById")
            .WithTags("Movies");

            return app;
        }
    }
}
