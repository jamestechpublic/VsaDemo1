using MediatR;
using VsaDemo1.Api.Repositories;
using VsaDemo1.Shared;
using VsaDemo1.Api.Models;

namespace VsaDemo1.Api.Features.Movies
{
    public static class CreateMovie
    {
        // Command
        public sealed record CreateMovieCommand(MovieDto Movie) : IRequest<MovieDto>;

        // Handler
        public sealed class CreateMovieHandler(MoviesDbContext _context) : IRequestHandler<CreateMovieCommand, MovieDto>
        {
            public async Task<MovieDto> Handle(CreateMovieCommand request, CancellationToken cancellationToken)
            {
                var entity = new Movie
                {
                    Title = request.Movie.Title,
                    Genre = request.Movie.Genre,
                    ReleaseYear = request.Movie.ReleaseYear
                };

                _context.Movies.Add(entity);
                await _context.SaveChangesAsync(cancellationToken);

                return new MovieDto
                {
                    Id = entity.Id,
                    Title = entity.Title,
                    Genre = entity.Genre,
                    ReleaseYear = entity.ReleaseYear
                };
            }
        }

        // Endpoint mapping
        public static IEndpointRouteBuilder MapCreateMovie(this IEndpointRouteBuilder app)
        {
            app.MapPost("/movies", async (MovieDto movie, IMediator mediator) =>
            {
                var result = await mediator.Send(new CreateMovieCommand(movie));
                return Results.Created($"/movies/{result.Id}", result);
            })
            .WithName("CreateMovie")
            .WithTags("Movies");

            return app;
        }
    }
}
