using MediatR;
using VsaDemo1.Api.Repositories;

namespace VsaDemo1.Api.Features.Movies
{
    public static class DeleteMovie
    {
        // Command
        public sealed record DeleteMovieCommand(int Id) : IRequest<bool>;

        // Handler
        public sealed class DeleteMovieHandler(MoviesDbContext _context) : IRequestHandler<DeleteMovieCommand, bool>
        {
            public async Task<bool> Handle(DeleteMovieCommand request, CancellationToken cancellationToken)
            {
                var entity = await _context.Movies.FindAsync(request.Id, cancellationToken);
                if (entity is null) return false;

                _context.Movies.Remove(entity);
                await _context.SaveChangesAsync(cancellationToken);

                return true;
            }
        }

        // Endpoint mapping
        public static IEndpointRouteBuilder MapDeleteMovie(this IEndpointRouteBuilder app)
        {
            app.MapDelete("/movies/{id}", async (int id, IMediator mediator) =>
            {
                var success = await mediator.Send(new DeleteMovieCommand(id));
                if (!success) return Results.NotFound("Movie not found.");
                return Results.NoContent();
            })
            .WithName("DeleteMovie")
            .WithTags("Movies");

            return app;
        }
    }

}
