﻿using Microsoft.EntityFrameworkCore;
using VsaDemo1.Api.Models;

namespace VsaDemo1.Api.Repositories
{
    public class MoviesDbContext : DbContext
    {
        public MoviesDbContext(DbContextOptions<MoviesDbContext> options) : base(options)
        {
        }
        public DbSet<Movie> Movies { get; set; }
    }
}
