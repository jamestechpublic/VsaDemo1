
using Microsoft.EntityFrameworkCore;
using Scalar.AspNetCore;
using VsaDemo1.Api.Features.Movies;
using VsaDemo1.Api.Repositories;

namespace VsaDemo1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddAuthorization();

            builder.Services.AddDbContext<MoviesDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("MoviesDbConnection")));

            // Register MediatR
            builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(Program).Assembly));

            builder.Services.AddOpenApi();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.MapScalarApiReference();
            }

            // Movies feature endpoints
            app.MapGetAllMovies();
            app.MapGetMovieById();
            app.MapCreateMovie();
            app.MapUpdateMovie();
            app.MapDeleteMovie();

            app.UseHttpsRedirection();

            app.UseAuthorization();

            app.Run();
        }
    }
}
